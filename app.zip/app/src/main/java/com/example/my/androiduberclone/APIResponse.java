package com.example.my.androiduberclone;

public class APIResponse {

    String message;
}
